import React from "react";
import { useGetAllCars } from "./hooks/useGetAllCars";
import { Link } from "react-router-dom";

const Cars = () => {
  const { allCars, loading, error } = useGetAllCars();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-lg font-semibold animate-pulse text-gray-600">
          Loading cars...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="bg-red-100 text-red-600 px-6 py-4 rounded-lg shadow">
          Error: {error}
        </div>
      </div>
    );
  }

  if (!allCars || allCars.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <p className="text-gray-500 text-lg">No cars available.</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
    <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold mb-8 text-gray-800">
        Available Cars
      </h2>


      <input type="text" placeholder="search for car" className="py-2 px-2 border-0 outline-1"/>
    </div>



      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {allCars.map((car) => (
          <div
            key={car._id}
            className="bg-white rounded-2xl shadow-md hover:shadow-xl transition duration-300 overflow-hidden group"
          >
            <Link to={`/cars/${car._id}`} className="h-56 w-full overflow-hidden">
              <img
                src={car.image}
                alt={car.title}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
            </Link>

            <div className="p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-2">
                {car.title}
              </h3>

              <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                {car.description}
              </p>

              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-indigo-600">
                  ${Number(car.price).toLocaleString()}
                </span>

                <span className="text-xs bg-indigo-100 text-indigo-600 px-3 py-1 rounded-full">
                  {car.category}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Cars;
