import axios from "axios";
import { useEffect, useState } from "react";
import axiosInstance from "../../../../api/axiosInstance";

export const useGetAllCars = () => {

    const [allCars, setAllCars] = useState([])
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)


   async function getAllCars() {
    setLoading(true)
        try {
            // const res = await axios.get('http://localhost:3000/api/v1/cars');
            const res = await axiosInstance.get('/cars');
            setAllCars(res.data.allCars)
        } catch (error) {
            console.log(error)
            setError(error.message || 'Something went wrong')
        }finally{
            setLoading(false)
        }
    }

    useEffect(()=>{
        getAllCars()
    },[])
    
    return{
        allCars,
        loading,
        error,
        getAllCars
    }

}